use musimundos;
select * from canciones;
select substr(upper(nombre),1,10) as nombre, sec_to_time(round(milisegundos/1000)) seg,
format((bytes/1000),0) kb, format(precio_unitario,3) precio, 
case 
	when length(compositor) = 0 or compositor is null then "<sin datos>"
	when position("," in compositor) <> 0 then substr(compositor, 1, position("," in compositor) - 1)
    when position("&" in compositor) <> 0 then left(compositor, position("&" in compositor) - 1)
	else compositor
end as compositor
 from canciones; 
 
 SELECT LEFT( UPPER(nombre), 10 ) AS CANCION,
     SEC_TO_TIME( ROUND(milisegundos/1000) ) AS MINUTOS,
     ROUND(bytes/1000) AS KBYTES,
     CONCAT( '$', FORMAT(precio_unitario, 3) ) AS PRECIO,
     CASE 
           WHEN  compositor = '' OR compositor IS NULL THEN '<sin datos>'
	 WHEN compositor NOT LIKE '%,%' THEN compositor
     	 ELSE LEFT( compositor, LOCATE(',', compositor) -1) 
     END AS COMPOSITOR
FROM canciones;

select * from formatos
where compositor like "%a";