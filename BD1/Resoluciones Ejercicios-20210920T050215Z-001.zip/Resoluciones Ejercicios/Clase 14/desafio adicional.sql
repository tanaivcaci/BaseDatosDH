-- ejercitacion adicional clase 14

SELECT * FROM movies
JOIN genres
ON movies.genre_id = genres.id;

-- SON IGUALES

SELECT * FROM movies, genres
WHERE movies.genre_id = genres.id;

-- 2 LISTAR LOS TITULOS DE LOS EPISODIOS CON EL NOMBRE Y APELLIDO DE LOS ACTORES

SELECT * FROM episodes;
select * FROM actor_episode;
SELECT * FROM actors;
select * from series;

SELECT episodes.title, episodes.rating, concat(first_name, " ", last_name)AS ACTORS FROM episodes
LEFT JOIN actor_episode
ON episodes.id = actor_episode.episode_id
RIGHT JOIN actors
on actor_episode.actor_id = actors.id
ORDER BY ACTORS;

-- inventado
SELECT episodes.title, episodes.rating, concat(first_name, " ", last_name), series.title FROM episodes
INNER JOIN actor_episode
ON episodes.id = actor_episode.episode_id
INNER JOIN actors
on actor_episode.actor_id = actors.id
INNER JOIN seasons
ON episodes.season_id = seasons.id
INNER JOIN series
ON seasons.serie_id = series.id;

-- 3 ACTORES QUE HAYAN TRABAJADO EN LA GUERRA DE LAS GALAXIAS

select * from movies;

select * from movies
INNER JOIN actor_movie
ON movies.id = actor_movie.movie_id
INNER JOIN actors
ON actor_movie.actor_id = actors.id
where title like "%la guerra%";

select * from actors
INNER JOIN actor_movie
ON actor_movie.actor_id = actors.id
INNER JOIN movies
ON movies.id = actor_movie.movie_id 
where title like "%la guerra%";

select * from actor_movie
INNER JOIN actors
ON actor_movie.actor_id = actors.id
INNER JOIN movies
ON movies.id = actor_movie.movie_id 
where title like "%la guerra%";

select genres.name, count(*) as cantidad from movies
inner join genres
on movies.genre_id = genres.id
group by genres.name
order by name;