-- DESAFIO EXTRA JOIN
-- Reportes - JOINS
-- 1. Obtener los artistas que han actuado en una o más películas.

select * from artista;
select * from pelicula;
select * from artista_x_pelicula;

select * from artista
inner join artista_x_pelicula
on artista.id = artista_x_pelicula.artista_id
inner join pelicula
on pelicula.id = artista_x_pelicula.pelicula_id;

-- 2. Obtener las películas donde han participado más de un artista según nuestra base de datos.
select count(artista_id), pelicula_id, titulo from artista
inner join artista_x_pelicula
on artista.id = artista_x_pelicula.artista_id
inner join pelicula
on pelicula.id = artista_x_pelicula.pelicula_id
group by pelicula_id
having count(artista_id) > 1;

select artista_id, apellido, nombre, pelicula_id from artista
inner join artista_x_pelicula
on artista.id = artista_x_pelicula.artista_id
inner join pelicula
on pelicula.id = artista_x_pelicula.pelicula_id
order by pelicula_id;

-- 3. Obtener aquellos artistas que han actuado en alguna película, incluso
-- aquellos que aún no lo han hecho, según nuestra base de datos.
select * from artista
left join artista_x_pelicula
on artista.id = artista_x_pelicula.artista_id
left join pelicula
on pelicula.id = artista_x_pelicula.pelicula_id;

-- 4. Obtener las películas que no se le han asignado artistas en nuestra base de datos.

select * from artista
right join artista_x_pelicula
on artista.id = artista_x_pelicula.artista_id
right join pelicula
on pelicula.id = artista_x_pelicula.pelicula_id
where artista_id is null;

select * from pelicula
left join artista_x_pelicula
on pelicula.id = artista_x_pelicula.pelicula_id
left join artista
on artista.id = artista_x_pelicula.artista_id
where artista_id is null;

-- 5. Obtener aquellos artistas que no han actuado en alguna película, según nuestra base de datos.

select * from artista
left join artista_x_pelicula
on artista.id = artista_x_pelicula.artista_id
left join pelicula
on pelicula.id = artista_x_pelicula.pelicula_id
where artista_id is null;

-- 6. Obtener aquellos artistas que han actuado en dos o más películas según nuestra base de datos.
select apellido, nombre, count(pelicula.id) from artista
join artista_x_pelicula
on artista.id = artista_x_pelicula.artista_id
join pelicula
on pelicula.id = artista_x_pelicula.pelicula_id
group by artista_id
having count(pelicula.id) >= 2;

-- 7. Obtener aquellas películas que tengan asignado uno o más artistas, incluso 
-- aquellas que aún no le han asignado un artista en nuestra base de datos.
select artista_id, titulo from artista
right join artista_x_pelicula
on artista.id = artista_x_pelicula.artista_id
right join pelicula
on pelicula.id = artista_x_pelicula.pelicula_id
order by artista_id;

select count(artista_id), titulo from artista
right join artista_x_pelicula
on artista.id = artista_x_pelicula.artista_id
right join pelicula
on pelicula.id = artista_x_pelicula.pelicula_id
group by artista_id, pelicula.id
order by count(artista_id);

