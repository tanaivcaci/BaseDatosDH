-- consultando la BD e-market
use emarket;
-- CLIENTES
-- 1) ¿Cuántos clientes existen?
select count(*) from clientes;

-- 2) ¿Cuántos clientes hay por ciudad?
select ciudad, count(*) from clientes
group by ciudad
order by count(*) desc;

-- FACTURAS
select * from facturas;
-- 1. ¿Cual es el total de transporte?
select sum(transporte)
from facturas;
-- 2. ¿Cual es el total de transporte por EnvioVia (empresa de envío)?
select enviovia, sum(transporte) from facturas
group by enviovia;
-- 3. Calcular la cantidad de facturas por cliente. Ordenar descendentemente por cantidad de facturas.
select clienteid, count(*) from facturas
group by clienteid
order by count(*) desc;
-- Obtener el Top 5 de clientes de acuerdo a su cantidad de facturas.
select clienteid, count(*) from facturas
group by clienteid
order by count(*) desc
limit 5;
-- ¿Cual es el país de envío menos frecuente de acuerdo a la cantidad de facturas?
select paisenvio, count(*) from facturas
group by paisenvio
order by count(*)
limit 1;
-- Se quiere otorgar un bono al empleado con más ventas. ¿Qué ID de empleado realizó más operaciones de ventas?
select empleadoid, count(*) from facturas
group by empleadoid
order by count(*) desc
limit 1;

-- FACTURA DETALLE
-- ¿Cuál es el producto que aparece en más líneas de la tabla Factura Detalle?
select * from facturadetalle;
select productoid, count(*) from facturadetalle
group by productoid
order by count(*) desc
limit 1;
-- 2) ¿Cuál es el total facturado? Considerar que el total facturado es la suma de cantidad por precio unitario.
select sum(preciounitario * cantidad) as "precio total"
from facturadetalle;
-- ¿Cuál es el total facturado para los productos ID entre 30 y 50?
select sum(preciounitario * cantidad) as "precio total"
from facturadetalle
where productoid between 30 and 50;
-- ¿Cuál es el precio unitario promedio de cada producto?
select productoid, avg(preciounitario)
from facturadetalle
group by productoid;
-- ¿Cuál es el precio unitario máximo?
select avg(preciounitario)
from facturadetalle;

-- JOINS
-- 1) Generar un listado de todas las facturas del empleado 'Buchanan'.
select apellido, facturaid from empleados
inner join facturas
on empleados.empleadoid = facturas.empleadoid
where apellido like "%buchanan%";

-- 2) Generar un listado con todos los campos de las facturas del correo 'Speedy Express'.
select * from facturas;
select * from correos;

select facturas.*, compania from facturas
join correos
on correos.correoid = facturas.enviovia
where compania = "speedy express";

-- 3) Generar un listado de todas las facturas con el nombre y apellido de los empleados.

select apellido, nombre, facturaid from facturas
inner join empleados
on facturas.empleadoid = empleados.empleadoid;

-- 4) Mostrar un listado de las facturas de todos los clientes “Owner” y país de envío “USA”.
select * from clientes
join facturas
on clientes.clienteid = facturas.clienteid
where clientes.titulo = "Owner" and paisenvio = "usa";

-- 5) Mostrar todos los campos de las facturas del empleado cuyo apellido sea “Leverling” o que incluyan el producto id = “42”.
select facturas.*, productoid from facturas
inner join facturadetalle
on facturas.facturaid = facturadetalle.facturaid
inner join empleados
on empleados.empleadoid = facturas.empleadoid
where apellido = "leverling" or productoid = 42;

-- 6) Mostrar todos los campos de las facturas del empleado cuyo apellido sea “Leverling” y que incluya los producto id = “80” o ”42”.

select facturas.*, productoid from facturas
inner join facturadetalle
on facturas.facturaid = facturadetalle.facturaid
inner join empleados
on empleados.empleadoid = facturas.empleadoid
where apellido = "leverling" and productoid in (42, 80);

-- 7) Generar un listado con los cinco mejores clientes, según sus importes de compras total (PrecioUnitario * Cantidad).

select clientes.clienteid, sum(preciounitario * cantidad) as total from facturas
inner join facturadetalle
on facturas.facturaid = facturadetalle.facturaid
inner join clientes
on clientes.clienteid = facturas.clienteid
group by clientes.clienteid
order by total desc
limit 5;

select clienteid, sum(preciounitario * cantidad) as total from facturas
inner join facturadetalle
on facturas.facturaid = facturadetalle.facturaid
group by clienteid
order by total desc
limit 5;

-- 8) Generar un listado de facturas, con los campos id, nombre y apellido del cliente,
-- fecha de factura, país de envío, Total, ordenado de manera descendente por
-- fecha de factura y limitado a 10 filas.

select facturas.facturaid, contacto, fechafactura, paisenvio, preciounitario * cantidad as total from facturas
inner join facturadetalle
on facturas.facturaid = facturadetalle.facturaid
inner join clientes
on clientes.clienteid = facturas.clienteid
order by facturaid desc;

select facturas.facturaid, contacto, fechafactura, paisenvio, sum(preciounitario * cantidad) as total from facturas
inner join facturadetalle
on facturas.facturaid = facturadetalle.facturaid
inner join clientes
on clientes.clienteid = facturas.clienteid
group by facturas.facturaid
order by fechafactura desc
